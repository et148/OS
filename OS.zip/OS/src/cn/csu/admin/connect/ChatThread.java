package cn.csu.admin.connect;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import cn.csu.connect.util.*;
import cn.csu.connect.view.*;
import cn.csu.connect.vo.*;


public class ChatThread extends Thread implements ActionListener{
	private Socket socket=null;
    private ObjectInputStream ois=null;
    private ObjectOutputStream oos=null;
    private String osuser=null;
    private AdminChatFrame admin=null;
    private boolean canRun=true;
    public static int c=0;
    
	 public ChatThread(Socket socket,AdminChatFrame admin) throws Exception{
  	   this.socket=socket;
  	   this.admin=admin;
  	   oos=new ObjectOutputStream(socket.getOutputStream());
  	   ois=new ObjectInputStream(socket.getInputStream());
     }
	 
	 public void run() {
  	   try {
  		   while(canRun) {  			   
  			   Message msg=(Message)ois.readObject();
  			   /*����֮��ת��*/
  			   String type=msg.getType();
  			   System.out.println(type);
  			   if(type.equals(Conf.LOGIN)) {
  				   this.handleLogin(msg);//������¼��Ϣ
  			   }else if(type.equals(Conf.MESSAGE)) {
  				   this.handleMessage(msg);//�������͵���Ϣ
  				   this.recordMessage(msg);//��¼��Ϣ
  			   }
  		   }
  	   }catch(Exception ex) {
  		   this.handleLogout();
  		  // ex.printStackTrace();
  	   }
     }
     /*******************������¼��Ϣ***************/
     public void handleLogin(Message msg) throws Exception{
       this.osuser = (String)msg.getContent();
  	   Message newMsg=new Message();
  	 /**�����̷߳���clients����**/
  	  admin.getClients().add(this);
  	  /* ��osuer���뵽userList�� */
  	  admin.getUserList().add(this.osuser);
  	  admin.addClient(this.osuser);
  	  /* ע�⣬Ӧ���ǽ����е������û���Ҫת�����ͻ�s�� */
  	  newMsg.setType(Conf.USERLIST);
  	  newMsg.setContent(admin.getUserList().clone());
  	  /* �����û���¼����Ϣ���������û� */
  	  this.sendMessage(newMsg,Conf.ALL);
  	  admin.setTitle("��ǰ���ߣ�"+admin.getClients().size()+"��");
  	  
     }
    
     /**********************��msg���������������Ϣ��ʽת��****************************/
     public void handleMessage(Message msg)throws Exception{
  	   String to=msg.getTo();
  	   sendMessage(msg,to);
     }
     /******************�����������ͻ��˷���һ���ÿͻ������ߵ���Ϣ***********************/
     public void handleLogout() {
  	   Message logoutMessage=new Message();
  	   logoutMessage.setType(Conf.LOGOUT);
  	   logoutMessage.setContent(this.osuser);
  	   admin.getClients().remove(this);            //���Լ���clients��ȥ��
  	   admin.getUserList().remove(this.osuser);
  	   try {
  		   sendMessage(logoutMessage,Conf.ALL);
  		   canRun=false;
  		   socket.close();
  	   }catch(Exception ex) {
  		   ex.printStackTrace();
  	   }
  	   admin.decClient(this.osuser);
  	   admin.setTitle("��ǰ���ߣ�"+admin.getClients().size()+"��");
  	   
     }
     /*****************����Ϣ����ĳ���ͻ���***********************/
     public void sendMessage(Message msg,String to) throws Exception{
  	   for(ChatThread ct:admin.getClients()) {
  		   if(ct.osuser.equals(to)||to.equals(Conf.ALL)) {
  			   if(ct.osuser.equals(msg.getFrom())) {
  				 
  			   }else {
  	 			 ct.oos.writeObject(msg);
  			     System.out.println("ccccccccccc");
  			   }
 
  		   }
  	   }
     }
     public void recordMessage(Message msg)throws Exception{
    	 String type = msg.getType();
    	 if(type.equals(Conf.ALL)) {
    		 this.admin.setTaMsg(msg.getFrom()+"��������˵��"+msg.getContent()+'\n');
    	 }else {
    		 this.admin.setTaMsg(msg.getFrom()+"��"+msg.getTo()+"˵��"+msg.getContent()+'\n');
    	 }
     }
     public void actionPerformed(ActionEvent e) {
  	   if(e.getSource()==admin.SendMessage) {
  		   c++;
  		   Message msg=new Message();
  		   msg.setType(Conf.SERVERMSG);
  		   String mess = admin.getMsg();
  		   msg.setContent(mess);
  		   if(c==1) {
      	      admin.setTaMsg("��������"+mess);   
  		   }
  		   try{
                  this.oos.writeObject(msg);
  		   }catch(Exception ex) {}
  		   if(c==admin.getClients().size()) {
  			   admin.clearTfMsg();
  			   c=0;
  		   }
  		   
  	   }else if(e.getSource()==admin.CloseClient) {
  		   Message msg=new Message();
  		   msg.setType(Conf.SERVEROUT);
  		   try {
      		   sendMessage(msg,admin.getSelectedClient());
      		   System.out.println("bbbbbbbbbbbbbb");
  		   }catch(Exception e2) {}
  	   }
     }
    
}

package cn.csu.connect.view;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.util.Vector;
import javax.swing.*;
import cn.csu.connect.vo.*;
import cn.csu.admin.connect.*;
public class AdminChatFrame extends JFrame implements Runnable{
	 /* �ͻ������� */
		private Socket socket=null;
		/* �������˽������� */
		private ServerSocket serverSocket =null;
		/* ����ͻ��˵��߳� */
		private Vector<ChatThread>clients=new Vector<ChatThread>();
		/* ���������û� */
		private Vector<String>userList=new Vector<String>();
		private JLabel lbClient=new JLabel("�����û�");
		public List lstClient=new List();
		private JLabel lbMessage=new JLabel("��Ϣ��¼");
		private JTextArea taMessage=new JTextArea();
		private JScrollPane spMessage=new JScrollPane(taMessage);
		public JTextField tf=new JTextField(10);
		private JButton jbt=new JButton("�ر�ͨ��");
		public JButton CloseClient=new JButton("�رո��û�");
		public JButton SendMessage=new JButton("����");
		
		private JPanel plClient=new JPanel(new BorderLayout());
		private JPanel plMsg=new JPanel(new BorderLayout());
		private JPanel plButton=new JPanel(new GridLayout(1,3));
		private JPanel plClient_Msg=new JPanel(new GridLayout(1,2));
		private JPanel plButton_tf=new JPanel(new GridLayout(2,1));
		private boolean canRun=true;
		
		public AdminChatFrame() throws Exception{
			this.setTitle("����Ա");
			plClient.add(lbClient,BorderLayout.NORTH);
			plClient.add(lstClient, BorderLayout.CENTER);
			plMsg.add(lbMessage, BorderLayout.NORTH);
			plMsg.add(spMessage, BorderLayout.CENTER);
			plButton.add(CloseClient);
			plButton.add(SendMessage);
			plButton.add(jbt);
			
			plClient_Msg.add(plClient);
			plClient_Msg.add(plMsg);
			plButton_tf.add(tf);
			plButton_tf.add(plButton);
			
			this.add(plClient_Msg,BorderLayout.CENTER);
			this.add(plButton_tf, BorderLayout.SOUTH);
			
			jbt.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(0);
				}
			});	
			this.setSize(400, 300);
			this.setVisible(false);
			/* �������˿��ٶ˿ڣ��������� */
			serverSocket =new ServerSocket(9999);
			/* ���տͻ������ӵ�ѭ����ʼ���� */
			new Thread(this).start();
		}
		
		public void run() {
			try {
				while(canRun) {
					socket=serverSocket.accept();
					ChatThread ct=new ChatThread(socket,this);
					/* �߳̿�ʼ���� */
					SendMessage.addActionListener(ct);
					CloseClient.addActionListener(ct);
				    tf.addActionListener(ct);			    
					ct.start();
					System.out.println("a");
				}
			}catch(Exception ex) {
				canRun=false;
				try {
					serverSocket.close();
				}catch(Exception e) {}
			}
		}
	public Vector<ChatThread> getClients(){
			return clients;
	}
	public Vector<String> getUserList(){
			return userList;
	}	
	public void canBeSeen() {
		this.setVisible(true);
	}
	
	public void addClient(String msg) {
		lstClient.add(msg);
	}
	public void decClient(String msg) {
		lstClient.remove(msg);
	}
	public String getMsg() {
		String s=tf.getText();
		return s;
	}
	public void clearTfMsg() {
		tf.setText("");
	}
	public String getSelectedClient() {
		String users=lstClient.getSelectedItem();
		return users.split(",")[0];
	}
	public int getClientNumber() {
		int a=lstClient.getItemCount();
		return a;
	}
	
	public void setTaMsg(String s) {
		taMessage.append(s);
	}
}

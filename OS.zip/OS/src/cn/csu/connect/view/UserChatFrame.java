package cn.csu.connect.view;
import java.awt.BorderLayout;
import cn.csu.user.domain.User;

import cn.csu.connect.vo.*;
import cn.csu.connect.util.*;
import java.awt.Color;
import java.awt.color.*;
import java.awt.GridLayout;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Vector;
import javax.swing.*;

import cn.csu.connect.vo.*;
public class UserChatFrame extends JFrame implements ActionListener,Runnable{
	
/****************************������ؼ�*****************************/
	private User user;
	private Socket socket=null;
	private ObjectInputStream ois=null;
	private ObjectOutputStream oos=null;
	private boolean canRun=true;
	private JLabel lbUser=new JLabel("�����û���");
	private List lstUser=new List();
	private JLabel lbMsg=new JLabel("�����¼��");
	private JTextArea taMsg=new JTextArea();
	private JScrollPane spMsg=new JScrollPane(taMsg);
	private JTextField tfMsg=new JTextField();
	private JButton btSend=new JButton("����");
    	
	private JPanel plUser=new JPanel(new BorderLayout());
	private JPanel plMsg=new JPanel(new BorderLayout());
	private JPanel plSend=new JPanel(new BorderLayout());
	private JPanel plSend_Msg=new JPanel(new BorderLayout());
	private JPanel plwhole = new JPanel(new GridLayout(1,2));
	
	public UserChatFrame(User user) {
		this.user = user;
		Message msg=new Message();
		msg.setType(Conf.LOGIN);
		msg.setContent(user.getUserName());
		try {
				socket=new Socket("127.0.0.1",9999);
				//����������˳��Ҫ��
				oos=new ObjectOutputStream(socket.getOutputStream());
				ois=new ObjectInputStream(socket.getInputStream());
				oos.writeObject(msg);
				Message receiveMsg=(Message)ois.readObject();
				String type=receiveMsg.getType();
				if(type.equals(Conf.LOGINFALL)) {
					JOptionPane.showMessageDialog(this, "��¼ʧ��");
					socket.close();
					return;
				}
				this.initFrame();
				this.initUserList(receiveMsg);
				new Thread(this).start();
			}catch(Exception ex) {
//				ex.printStackTrace();
				JOptionPane.showMessageDialog(this, "����Ա������");
				this.dispose();				
			}
		btSend.addActionListener(this);
	}
	void initUserList(Message msg) {
		lstUser.removeAll();
		lstUser.add(Conf.ALL);
		lstUser.select(0);
		Vector<String>userListVector = (Vector<String>)msg.getContent();
		for(String us:userListVector) {
			lstUser.add(us);
		}
	}
	
	public void initFrame() {
		this.setTitle(user.getUserName()+" ״̬��������");
		plUser.add(lbUser, BorderLayout.NORTH);
		plUser.add(lstUser,BorderLayout.CENTER);
		plMsg.add(lbMsg, BorderLayout.NORTH);
		plMsg.add(spMsg, BorderLayout.CENTER);
		plSend.add(btSend,BorderLayout.EAST);
		plSend.add(tfMsg,BorderLayout.CENTER);
		plSend_Msg.add(plMsg,BorderLayout.CENTER);
		plSend_Msg.add(plSend, BorderLayout.SOUTH);
		plwhole.add(plUser);
		plwhole.add(plSend_Msg);
		this.add(plwhole);		
//		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(500, 500);
		this.setVisible(true);
	}
	public void run() {
		try {
			while(canRun) {
				Message msg=(Message)ois.readObject();
				if(msg.getType().equals(Conf.MESSAGE)) {
					//��ChatFrame��ta����������
					taMsg.append(msg.getFrom()+"˵��"+msg.getContent()+"\n");
				}else if(msg.getType().equals(Conf.USERLIST)) {
					this.initUserList(msg);
				}else if(msg.getType().equals(Conf.LOGOUT)) {
					String user=(String)msg.getContent();
					lstUser.remove(user);
				}else if(msg.getType().equals(Conf.SERVEROUT)) {
					canRun=false;
					javax.swing.JOptionPane.showMessageDialog(this, "����Ա��ֹ��ͨ��");
					System.exit(-1);
				}else if(msg.getType().equals(Conf.SERVERMSG)) {
					taMsg.append("����Ա˵��"+msg.getContent()+"\n");
				}
			}
		}catch(Exception ex) {
			ex.printStackTrace();
			canRun=false;
			javax.swing.JOptionPane.showMessageDialog(this, "�Բ�����������");
			System.exit(-1);
		}
}
	
	public void actionPerformed(ActionEvent e) {
		try {
			if(e.getSource()==btSend) {
				Message msg=new Message();
				msg.setType(Conf.MESSAGE);
				msg.setContent(tfMsg.getText());
				msg.setFrom(this.user.getUserName());
				String toInfo=lstUser.getSelectedItem();
				msg.setTo(toInfo.split(",")[0]);
				oos.writeObject(msg);
				taMsg.append("��˵:"+tfMsg.getText()+"\n");
				tfMsg.setText("");
			}			
		}catch(Exception ex) {
			JOptionPane.showMessageDialog(this, "��Ϣ�����쳣");
		}
	}
}

package cn.csu.user.Service;
/*
 * ��װ�û���CRUD
 */
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.List;


import cn.csu.user.domain.User;
import cn.csu.user.init.InitSingon;
import cn.csu.user.init.InitThread;
import cn.csu.user.util.FileUtils;
//����Ҫ����һ����ʼ����init
public class Service {
	static List<User> userList = null;
	
	//1,�û�ע��
	//�����������ǰ����Id
	public Boolean register(User user){
		//Ϊע���user�ú͵�id��Ȩ�޸�ֵ
		List<User> userList = InitSingon.userList;
		if(userList != null){
			Integer id = userList.get(userList.size()-1).getUserId()+1;
			user.setUserId(id);
			user.setIsAdmin(false);
		}
	     //���ļ�д��ͬʱд���ڴ�init
		BufferedWriter bw = null;
			try {
				InitSingon.userList.add(user);
				bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File("./user/user.txt"),true)));
				bw.write("isAdmin:"+user.getIsAdmin()+":"+"userId:"+user.getUserId()+":"+"userName:"+user.getUserName()+":"+"userPassword:"+user.getUserPassword()+"\n");
				
				return true;
			} catch (IOException e){
				e.printStackTrace();
			}finally{
				try {
					bw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
	       return false;
	}
	
	//2,ϵͳ��½ʱ��֤
	public User validate(String userName,String password) throws IOException{
		//�ж���ͨ���û��Ƿ�Ϸ�
		List<User> userList = InitSingon.userList;
		for(User user:userList){
			if(user.getUserName().equals(userName)&&user.getUserPassword().equals(password)){
				return user;
			}
		}
		return null;
	}
	
	//�޸��û���Ϣ
	static public Boolean updateUser(){
		List<User> userList = InitSingon.userList;
		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File("./user/user.txt"),false)));
			bw.write("");
		} catch (IOException e){
			e.printStackTrace();
		}finally{
			try {
				bw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}    	
        }
		
		BufferedWriter bw2 = null;
		try {
			bw2 = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File("./user/user.txt"),true)));
//			System.out.println(userList);
			for(User user:userList) {
//				System.out.println("isAdmin:"+user.getIsAdmin()+":"+"userId:"+user.getUserId()+":"+"userName:"+user.getUserName()+":"+"userPassword:"+user.getUserPassword());
				bw2.write("isAdmin:"+user.getIsAdmin()+":"+"userId:"+user.getUserId()+":"+"userName:"+user.getUserName()+":"+"userPassword:"+user.getUserPassword()+"\n");
			}
			return true;
		} catch (IOException e){
			e.printStackTrace();
		}finally{
			try {
				bw2.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}    	
        }
		return false;
	}
	
	
	//ɾ���û���Ϣ
	public Boolean deleteUser(User user){
		for(int i=0;i<InitSingon.userList.size();i++){
			if(InitSingon.userList.get(i).getUserId().equals(user.getUserId())){
				InitSingon.userList.remove(i);
				//�û�����
			    //InitThread.threadList.remove(i);
				for(User user1:InitSingon.userList){
					System.out.println("ʣ���û�"+user1);
				}
				new FileUtils().writeFile(InitSingon.userList);
				return true;
			}
		}
		return false;
		
	}
	
	//�����û�����ѯ�û�
    public  User findUserByName(String userName){
    	for(User user:InitSingon.userList){
    		if(user.getUserName().equals(userName)){
    			return user;
    		}
    	}
    	return null;
    }
    
    //����Ϊ����Ա����
    public void setAdmin(String userName) {
    	List<User> userList = InitSingon.userList;
    	for(User user:userList){
			if(user.getUserName().equals(userName)){
				user.setIsAdmin(true);				
			}
		}
    	BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File("./user/user.txt"),false)));
			bw.write("");
		} catch (IOException e){
			e.printStackTrace();
		}finally{
			try {
				bw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}    	
        }
		BufferedWriter bw2 = null;
		try {
			bw2 = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File("./user/user.txt"),true)));
			for(User user:userList) {
				bw2.write("isAdmin:"+user.getIsAdmin()+":"+"userId:"+user.getUserId()+":"+"userName:"+user.getUserName()+":"+"userPassword:"+user.getUserPassword()+"\n");
			}
		} catch (IOException e){
			e.printStackTrace();
		}finally{
			try {
				bw2.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}    	
        }
}
    //ȡ������Ա����
    public void setNotAdmin(String userName) {
    	List<User> userList = InitSingon.userList;
    	for(User user:userList){
			if(user.getUserName().equals(userName)){
				user.setIsAdmin(false);				
			}
		}
    	BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File("./user/user.txt"),false)));
			bw.write("");
		} catch (IOException e){
			e.printStackTrace();
		}finally{
			try {
				bw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}    	
        }
		BufferedWriter bw2 = null;
		try {
			bw2 = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File("./user/user.txt"),true)));
			for(User user:userList) {
				bw2.write("isAdmin:"+user.getIsAdmin()+":"+"userId:"+user.getUserId()+":"+"userName:"+user.getUserName()+":"+"userPassword:"+user.getUserPassword()+"\n");
			}
		} catch (IOException e){
			e.printStackTrace();
		}finally{
			try {
				bw2.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}    	
        }
    }
}

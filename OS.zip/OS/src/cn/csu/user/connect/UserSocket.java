package cn.csu.user.connect;

public class UserSocket {

}

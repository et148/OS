package cn.csu.user.init;

import java.util.ArrayList;
import java.util.List;

import cn.csu.user.thread.UserThread;
//����ȫ�ֵ��̴߳洢��
public class InitThread {
	public static List<UserThread> threadList = new ArrayList<UserThread>();
	private InitThread initThread = new InitThread();
	private InitThread(){
	}
}

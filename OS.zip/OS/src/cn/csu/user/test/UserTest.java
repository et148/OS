package cn.csu.user.test;

import cn.csu.user.domain.User;
import cn.csu.user.view.UserView;

public class UserTest {
	public static void main(String[] args) {
		User user = new User();
		user.setUserId(1);
		UserView uv = new UserView(user);
	}
}

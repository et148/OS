package cn.csu.user.view;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;

import cn.csu.user.Service.Service;
import cn.csu.user.domain.User;
import cn.csu.user.init.InitSingon;

public class UserViewManager {
	//��ǰ��½�û���Ϣ
	private User userGloble;
	//����list���浱ǰ�����ߵ��������û�,������AWT����list
    private JList onLineList = null;
    private JFrame jFrame = null;
    private JPanel jPanel = null;
    private JLabel jLabel = null;
    //�趨�Ҽ��˵�
    private JComboBox box = null;
    //�����Ҽ��˵�
    private JPopupMenu rightmenu = null;
    
    //��ʼ��
	public UserViewManager(User user){
		this.userGloble = user;
		onLineList = new JList();
		jFrame = new JFrame("ϵͳ�û�������");
		jPanel = new JPanel();
		jLabel = new JLabel();
		jFrame.setAlwaysOnTop(true);
		jFrame.setBounds(200,100,300,500);
		jPanel.setBounds(100,100,300,500);
		java.util.List<String> resultList = new ArrayList<String>();
				
		//��ʼ��list�е�����
		for(int i=0;i<InitSingon.userList.size();i++){			
			if(this.userGloble.getUserId().equals(InitSingon.userList.get(i).getUserId())){
				continue;
			}			
		    resultList.add(InitSingon.userList.get(i).getUserName());
		}
		
		//��ʼ���Ҽ���ť����
		Icon button1 = new ImageIcon("./src/icons/menu_add.gif");
		Icon button2 = new ImageIcon("./src/icons/menu_del.gif");
		Icon button3 = new ImageIcon("./src/icons/menu_refresh.gif");
		Icon button4 = new ImageIcon("./src/icons/2_open.gif");
		//Icon button5 = new ImageIcon("./src/icons/search_new.gif");
	    
		//��ʼ����ť�е�����
		rightmenu = new JPopupMenu();
		JMenuItem jm1 = new JMenuItem("�����û�",button1);
		JMenuItem jm2 = new JMenuItem("ɾ���û�",button2);
		JMenuItem jm3 = new JMenuItem("���ù���Ա",button3);
		JMenuItem jm4 = new JMenuItem("ȡ������Ա",button4);
		//JMenuItem jm5 = new JMenuItem("���з�ʽ",button5);

		//���ӵ��Ҽ��˵�����
		rightmenu.add(jm1);
		rightmenu.add(jm2);
		rightmenu.add(jm3);
		rightmenu.add(jm4);
		//rightmenu.add(jm5);
		
		
		//�����˵�ǰ�û��ĸ��û���д�뵽list��
		onLineList.setListData(resultList.toArray());
		onLineList.setFixedCellHeight(30);
		onLineList.setFixedCellWidth(290);
		onLineList.setSelectionForeground(Color.red);
		onLineList.setVisible(true);
		onLineList.setBackground(Color.getHSBColor(100, 100, 100));
	    jLabel = new JLabel("��ǰϵͳ�е��û�����:");
	    onLineList.setComponentPopupMenu(rightmenu);
		
		
	    //�� ������������
		jPanel.add(onLineList);
	    
		//�����ڵ����Ӽ���
		//�趨�û����Ӽ���begin
		jm1.addActionListener(new ActionListener() {
			JTextField newUserName = null;
	    	JPasswordField userPassword = null;
	    	JPasswordField apassword = null;
	    	
	    	JButton submit = new JButton("ע��");
	    	JButton reset = new JButton("����");
	    	
	    	JLabel userJLabel = null;
	    	JLabel passwordJLabel = null;
	    	JLabel aPasswordLable = null;
	    	
	    	JFrame newUserFrame = null;
	    	JPanel newUserPanel = null;
	    	
	    	User user = null;
	    	
	    	
			@Override
			public void actionPerformed(ActionEvent e){
				String name = (String)onLineList.getSelectedValue();
				
				newUserFrame = new JFrame("�½��û�");
				newUserPanel = new JPanel();
				newUserPanel.setLayout(null);
				
				
				userJLabel = new JLabel("�û���:");
				userJLabel.setBounds(5, 5,50, 30);
			    newUserName = new JTextField();
				newUserName.setBounds(90,5,100,30);
				
				passwordJLabel = new JLabel("����:");
				passwordJLabel.setBounds(5,40,50,30);
				userPassword = new JPasswordField();
				userPassword.setBounds(90, 40, 100, 30);
				
				aPasswordLable = new JLabel("�ٴ���������:");
				aPasswordLable.setBounds(5, 75, 98, 30);
				apassword = new JPasswordField();
				apassword.setBounds(90, 75,100,30);
				
				submit.setText("ע��");
				submit.setBounds(10,110, 80, 30);
				reset.setText("����");
				reset.setBounds(110,110, 80, 30);
				
				//�������
				newUserPanel.add(userJLabel);
				newUserPanel.add(newUserName);
				
				newUserPanel.add(passwordJLabel);
				newUserPanel.add(userPassword);
			
				newUserPanel.add(aPasswordLable);
				newUserPanel.add(apassword);
			   
				newUserPanel.add(submit);
				newUserPanel.add(reset);
				
				
				
				//�Ӵ������Ӽ���
				//ע�����
				submit.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						user = new User();
						user.setUserName(newUserName.getText());
						if(!userPassword.getText().equals(apassword.getText())){
							//������ʾ��
							JOptionPane.showMessageDialog(newUserPanel,"���벻ƥ��");
							apassword.setText("");
						}else{
							user.setUserPassword(userPassword.getText());
							Service service = new Service();
							if(service.register(user)){
								JOptionPane.showMessageDialog(newUserPanel,"��,��ϲ!ע��ɹ��ˣ�");
								newUserFrame.dispose();
								jFrame.dispose();
								
								//ˢ��ҳ��
								UserViewManager manager = new UserViewManager(userGloble); 
							}
						}
					}
				});
				
				//���ü���
				reset.addActionListener(new ActionListener() {
				    @Override
					public void actionPerformed(ActionEvent e) {
				    	newUserName.setText("");
				    	userPassword.setText("");
				    	apassword.setText("");
					}
				});
				
				
				//�Ӵ�������
				newUserFrame.setBounds(150,300,200,200);
				newUserFrame.add(newUserPanel);
				newUserPanel.setVisible(true);
				newUserFrame.setVisible(true);
				newUserFrame.setResizable(false);
				newUserFrame.setAlwaysOnTop(true);
			}
		});
		//�趨�û����Ӽ���end
		
		//�趨�û�ɾ������begin
		jm2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//�õ�ѡ���û����û���
				String delUserName  = (String)onLineList.getSelectedValue();
				
				//�鵽����û�
				User user  = new Service().findUserByName(delUserName);
				
				if(new Service().deleteUser(user)){
					String delMessage = user.getUserName()+"ɾ���ɹ�";
					JOptionPane.showMessageDialog(jPanel,delMessage);
					//����ҳ���ˢ��
					jFrame.dispose();
					//ˢ��ҳ��
					UserViewManager manager = new UserViewManager(userGloble);
					
				}
			}
		});
		
		jm3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String userName = (String)onLineList.getSelectedValue();
				Service service = new Service();
				service.setAdmin(userName);
				JOptionPane.showMessageDialog(null, "���óɹ�");
				
			}
		});
		
		jm4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String userName = (String)onLineList.getSelectedValue();
				Service service = new Service();
				service.setNotAdmin(userName);
				JOptionPane.showMessageDialog(null, "ȡ���ɹ�");
			}
		});
		//����������
	    jFrame.add(jLabel,new BorderLayout().NORTH);
		jFrame.add(jPanel);
		jFrame.setResizable(false);
		jFrame.setVisible(true);
	}
}

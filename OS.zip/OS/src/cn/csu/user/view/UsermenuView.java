package cn.csu.user.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JToolBar;

import cn.csu.user.Service.Service;
import cn.csu.user.domain.User;

import com.csu.filesys.server.FilesysServer;
import com.csu.filesys.view.FilesysPanel;
import com.csu.prosys.userInterface.MainFrame;
import com.csu.prosys.userInterface.NewPCBDialog;
import com.csu.prosys.userInterface.MainFrame.ToolBarAction;
import com.csu.prosys.util.ReadyQueue;
import com.csu.prosys.util.ReserveQueue;
import com.csu.thread.manager.TaskList;
import cn.csu.connect.view.*;
public class UsermenuView extends JFrame implements ActionListener{
	FilesysServer fss;
	User user;
	int sw=(int) Toolkit.getDefaultToolkit().getScreenSize().getWidth();
	int sh=(int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();
 	AdminChatFrame acf;
 	
 	//�ؼ�
 	JLabel la=new JLabel();//��ʾͷ��ı�ǩ
 	JLabel uid;
 	JLabel uname;
 	JLabel upassword;
 	JLabel uadmin;
 	JButton bt=new JButton("�޸�����");
 	
 	public UsermenuView(FilesysServer fss,User user){
		/**�û�ͷ��*/
 		ImageIcon icon = new ImageIcon(MainFrame.class.getResource("/icons/pp.JPG"));
		la = new JLabel(icon);
		la.setBounds(30, 60, icon.getIconWidth(), icon.getIconHeight());
		this.add(la);
		/**�û���Ϣ*/
		uid=new JLabel("ID��"+user.getUserId());
		uname=new JLabel("NAME:"+user.getUserName());
		upassword=new JLabel("PASSWORD:"+user.getUserPassword());
		uadmin=new JLabel("IS ADMIN:"+user.getIsAdmin());
		
		uid.setBounds(150,50,60,30);
		uid.setFont(new Font("����",Font.BOLD,20));
		uname.setBounds(150,75,200,30);
		uname.setFont(new Font("����",Font.BOLD,20));
		upassword.setBounds(150,100,200,30);
		upassword.setFont(new Font("����",Font.BOLD,20));
		uadmin.setBounds(150,125,200,30);
		uadmin.setFont(new Font("����",Font.BOLD,20));
		this.add(uid);
		this.add(uname);
		this.add(upassword);
		this.add(uadmin);
		
		bt.setBounds(290, 100, 80, 30);
		this.add(bt);
		bt.addActionListener(this);
		
		/**��������ʾ*/
		JToolBar toolBar = new JToolBar();
		toolBar.setFloatable(true);
		ToolBarAction tba_file = new ToolBarAction("FILE", new ImageIcon(//�½�
				MainFrame.class.getResource(("/icons/file.JPG"))), this);
		ToolBarAction tba_pro = new ToolBarAction("PROSESS", new ImageIcon(//��ʼ
				MainFrame.class.getResource(("/icons/pro.JPG"))), this);
		ToolBarAction tba_com = new ToolBarAction("COMMMUNICATE", new ImageIcon(//��ͣ
				MainFrame.class.getResource(("/icons/com.JPG"))), this);

		JButton jb;
		jb = toolBar.add(tba_file);
		jb.setActionCommand("FILE");
		jb.setToolTipText("�ļ�");
		jb.setFocusPainted(false);
		toolBar.addSeparator();		
		
		jb = toolBar.add(tba_pro);
		jb.setActionCommand("PROSESS");
		jb.setToolTipText("����");
		jb.setFocusPainted(false);
		toolBar.addSeparator();		
		
		jb = toolBar.add(tba_com);
		jb.setActionCommand("COMMMUNICATE");
		jb.setToolTipText("ͨ��");
		jb.setFocusPainted(false);
		toolBar.addSeparator();		
		
		toolBar.setBounds(0, 200, 400, 60);
		this.add(toolBar);	
				
		this.fss=fss;
		this.user=user;
		this.setLayout(null);
		
		JLabel jl=new JLabel("USER'S MESSAGE");
		jl.setBounds(110,10,360,40);
		jl.setFont(new Font("΢���ź�",Font.BOLD,20));		
		this.add(jl);
		this.setBackground(new Color(253,255,233));
		this.setSize(400,300);
		this.setLocation(sw/2-200, sh/2-150);
		this.setVisible(true);
		this.setTitle("�������ϵͳ");
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	
	public UsermenuView(FilesysServer fss,User user,AdminChatFrame acf){
		this.acf = acf;
		/**�û�ͷ��*/
 		ImageIcon icon = new ImageIcon(MainFrame.class.getResource("/icons/pp.JPG"));
		la = new JLabel(icon);
		la.setBounds(30, 60, icon.getIconWidth(), icon.getIconHeight());
		this.add(la);
		/**�û���Ϣ*/
		uid=new JLabel("ID��"+user.getUserId());
		uname=new JLabel("NAME:"+user.getUserName());
		upassword=new JLabel("PASSWORD:"+user.getUserPassword());
		uadmin=new JLabel("IS ADMIN:"+user.getIsAdmin());
		
		uid.setBounds(140,50,60,30);
		uid.setFont(new Font("����",Font.BOLD,20));
		uname.setBounds(140,75,200,30);
		uname.setFont(new Font("����",Font.BOLD,20));
		upassword.setBounds(140,100,200,30);
		upassword.setFont(new Font("����",Font.BOLD,20));
		uadmin.setBounds(140,125,200,30);
		uadmin.setFont(new Font("����",Font.BOLD,20));
		this.add(uid);
		this.add(uname);
		this.add(upassword);
		this.add(uadmin);
		
		bt.setBounds(295, 100, 80, 30);
		this.add(bt);
		bt.addActionListener(this);
		
		/**��������ʾ*/
		JToolBar toolBar = new JToolBar();
		toolBar.setFloatable(true);
		ToolBarAction tba_file = new ToolBarAction("FILE", new ImageIcon(//�½�
				MainFrame.class.getResource(("/icons/file.JPG"))), this);
		ToolBarAction tba_pro = new ToolBarAction("PROSESS", new ImageIcon(//��ʼ
				MainFrame.class.getResource(("/icons/pro.JPG"))), this);
		ToolBarAction tba_com = new ToolBarAction("COMMMUNICATE", new ImageIcon(//��ͣ
				MainFrame.class.getResource(("/icons/com.JPG"))), this);

		JButton jb;
		jb = toolBar.add(tba_file);
		jb.setActionCommand("FILE");
		jb.setToolTipText("�ļ�");
		jb.setFocusPainted(false);
		toolBar.addSeparator();		
		
		jb = toolBar.add(tba_pro);
		jb.setActionCommand("PROSESS");
		jb.setToolTipText("����");
		jb.setFocusPainted(false);
		toolBar.addSeparator();		
		
		jb = toolBar.add(tba_com);
		jb.setActionCommand("COMMMUNICATE");
		jb.setToolTipText("ͨ��");
		jb.setFocusPainted(false);
		toolBar.addSeparator();		
		
		toolBar.setBounds(0, 200, 400, 50);
		this.add(toolBar);	
				
		this.fss=fss;
		this.user=user;
		this.setLayout(null);
		
		JLabel jl=new JLabel("USER'S MESSAGE");
		jl.setBounds(110,10,360,40);
		jl.setFont(new Font("΢���ź�",Font.BOLD,20));		
		this.add(jl);
		this.setBackground(new Color(253,255,233));
		this.setSize(400,300);
		this.setLocation(sw/2-200, sh/2-150);
		this.setVisible(true);
		this.setTitle("�������ϵͳ");
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	
	public void init(){
		upassword.setText("PASSWORD:"+user.getUserPassword());
	}
	
	
	/**��������õ�����Ϊ�ˣ�ͼ�갴ť���������ؼ������¼��Ĵ���*/
	class ToolBarAction extends AbstractAction {
		UsermenuView frame;

		public ToolBarAction(String name, Icon icon, UsermenuView frame) {
			super(name, icon);
			this.frame = frame;
		}

		public void actionPerformed(ActionEvent e) {
			if(e.getActionCommand()=="FILE") {
				new FilesysPanel(fss,user);
			}else if(e.getActionCommand().equals("PROSESS")){
				new MainFrame();
			}else if(e.getActionCommand().equals("COMMMUNICATE")) {
				if(user.getUserName().equals("admin")) {
					acf.canBeSeen();
				}else {
					new UserChatFrame(user);
				}
			}
	}
		
}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==bt) {
			String ss=null;
			ss=JOptionPane.showInputDialog(ss);
			if(ss!=null) {
				this.user.setUserPassword(ss);
			if(Service.updateUser()) {System.out.println("xiugai ");init();}
			}
			
		}
	}

}

package com.csu.filesys.domain;

public class MyFile {
	public int fsize;
	public String fname;
	public String ftime;
	public String fcont;
	public int fownid;
	public int fgrpid;
	public int fmode;
}

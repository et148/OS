package com.csu.filesys.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeHelper {
	public String gettime(){
		return new SimpleDateFormat("yyyyMMddHHmm").format(new Date());
	}
}

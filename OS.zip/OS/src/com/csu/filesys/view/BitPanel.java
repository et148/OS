package com.csu.filesys.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JPanel;

import com.csu.filesys.domain.Disk;
import com.csu.filesys.domain.SuperBlock;
import com.csu.filesys.server.FilesysServer;

public class BitPanel extends JPanel{
	private static final long serialVersionUID = 1L;
	FilesysServer fss;
	FilesysPanel fp;
	public BitPanel(FilesysPanel fp){
		this.fss=fp.fss;
		this.fp=fp;
	}
	public void paint(Graphics g){
		super.paint(g);
		SuperBlock sb=fss.getSuperblock();

		//g.setFont(new Font("΢���ź�",Font.BOLD,16));
		g.drawString("���̿����", 100, 20);
		g.drawString("�����ڵ����", 90, 265);
		int tot1=100,tot2=80;
		
		//���ڵ��������,�Ȼ������ٻ���
		for(int i=0;i<Disk.BNUM;i++){
			int xx=i%10,yy=i/10;
			if(sb.bitblock[i]==1){
				tot1--;
				if(i<=11)g.setColor(Color.PINK);
				else g.setColor(Color.RED);
				g.fillRect(30+xx*20, 30+yy*20, 20, 20);
			}else if(sb.bitblock[i]==2){
//				tot1--;
			    g.setColor(Color.orange);
				g.fillRect(30+xx*20, 30+yy*20, 20, 20);
				sb.bitblock[i] = 1;
			}
		}
		g.setColor(Color.black);
		for(int i=0;i<=10;i++)g.drawLine(30,30+20*i,230,30+20*i);
		for(int i=0;i<=10;i++)g.drawLine(30+20*i, 30, 30+20*i, 230);

		
		//�������ڵ�������,�Ȼ������ٻ���
//		g.setColor(Color.red);
		for(int i=0;i<Disk.INUM;i++){
			g.setColor(Color.red);
			int xx=i%10,yy=i/10;
			if(sb.bitindex[i]==1){
				tot2--;
				g.fillRect(30+xx*20, 280+yy*20, 20, 20);
			}else if(sb.bitindex[i]==2){
//				tot1--;
			    g.setColor(Color.orange);
				g.fillRect(30+xx*20, 280+yy*20, 20, 20);
				sb.bitindex[i] = 1;
			}
		}
		g.setColor(Color.black);
		
		for(int i=0;i<=8;i++)g.drawLine(30,280+20*i,230,280+20*i);
		for(int i=0;i<=10;i++)g.drawLine(30+20*i, 280, 30+20*i, 440);
		
		//���ô�����Ϣ��ʾ
		fp.ft.jt[7].setText(512*tot1+"B");
		fp.ft.jt[9].setText(tot1+"");
		fp.ft.jt[10].setText(tot2+"");
	}

}

package com.csu.filesys.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.*;

import com.csu.filesys.domain.Disk;
import com.csu.filesys.domain.SuperBlock;
import com.csu.filesys.server.FilesysServer;
import com.csu.filesys.view.*;

public class DiskPanel extends JFrame{
	public JTextField jt[] ;
	public JLabel jl[];
	public JPanel jpl = new JPanel(null);
	public DiskPanel() {
		jl=new JLabel[12];
		jt=new JTextField[12];
		jl[11]=new JLabel("=== �� �� �� �� ===");
		jl[6]=new JLabel("�ܿռ�:");
		jl[7]=new JLabel("ʣ��ռ�:");
		jl[8]=new JLabel("���С:");
		jl[9]=new JLabel("ʣ���:");
		jl[10]=new JLabel("ʣ������:");
		jl[11].setBounds(100,20,200,23);
		jpl.add(jl[11]);
		for(int i=6;i<=10;i++){
			jl[i].setBounds(60,25+23*(i-5),80,23);
			jpl.add(jl[i]);
		}          
		for(int i=6;i<=10;i++){
			jt[i]=new JTextField();
			jt[i].setBounds(140, 25+23*(i-5), 120, 23);
			jt[i].setEditable(false);
			jpl.add(jt[i]);
		}     
		jt[6].setText("51200B");
		jt[8].setText("512B");
		jpl.setBackground(Color.WHITE);
		this.setVisible(false);
		this.setSize(350, 250);
		this.add(jpl);
		
		this.setLocation(500, 400);
	}
	public void setTextField(JTextField  jtf[]) {
		for(int i=6;i<=10;i++) {
			this.jt[i].setText(jtf[i].getText());
		}				
	}
	
	
}

package com.csu.filesys.view;

import java.awt.Color;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;

public class FilePropertyPanel extends JFrame{
	JLabel jl[];
	public JTextField jt[];
	JPanel jpl = new JPanel(null);
	Icon icon = new ImageIcon("./src/icons/file.png");
	public FilePropertyPanel() {
		jl=new JLabel[12];
		jt=new JTextField[12];
		//��ʾ�ļ���Ϣ
		jl[6]=new JLabel();
		jl[6].setIcon(icon);
		jl[0]=new JLabel("**** �� �� �� �� �� ****");
		jl[1]=new JLabel("�ļ���:");
		jl[2]=new JLabel("�ļ�����:");
		jl[3]=new JLabel("�ļ���С:");
		jl[4]=new JLabel("������ID:");
		jl[5]=new JLabel("�޸�ʱ��:");
		jl[0].setBounds(120,15,200,20);
		this.add(jl[0]);
		for(int i=1;i<=5;i++){
			jl[i].setBounds(90,40+30*i,80,23);
			jpl.add(jl[i]);
		}
		for(int i=1;i<=5;i++){
			jt[i]=new JTextField();
			jt[i].setBounds(170, 40+30*i, 120, 23);
			jt[i].setEditable(false);
			jpl.add(jt[i]);
		}
		jl[6].setBounds(50, 10, 30, 30);
		jpl.add(jl[6]);
		this.add(jpl);
		jpl.setBackground(Color.WHITE);
		this.setVisible(false);
		this.setSize(400, 300);
		//this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void setTextField(JTextField  jtf[]) {
		for(int i=1;i<=5;i++) {
			this.jt[i].setText(jtf[i].getText());
		}				
	}

}

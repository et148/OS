package com.csu.filesys.view;

import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.LinkedList;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreeSelectionModel;

import cn.csu.user.domain.User;
import cn.csu.user.init.InitThread;
import cn.csu.user.thread.UserThread;
import cn.csu.user.view.UserView;
import cn.csu.user.view.UserViewManager;

import com.csu.filesys.domain.MyFile;
import com.csu.filesys.domain.SuperBlock;
import com.csu.filesys.server.FilesysServer;
import com.csu.filesys.view.*;
public class FileTreePanel extends JPanel implements ActionListener{
	private static final long serialVersionUID = 1L;
	JPopupMenu rightmenu = null;
	JMenuItem jm[];
    Icon icon[];
	DefaultMutableTreeNode nodes[];
	DefaultTreeModel model;
	DiskPanel dp = new DiskPanel();
	JTree tree;
	JScrollPane jsp,jsp2;
	public JLabel jl[];
	public JTextField jt[];
	SuperBlock sb;
	String nowpath="#";
	MyFile mf;
	FileeditDialog fd;
	FilesysServer fss;
	FilesysPanel parent;
	BitPanel bp;
	FilePropertyPanel fpp = new FilePropertyPanel();
	User user;
	public FileTreePanel(FilesysPanel fp){
		this.parent=fp;
		this.user=fp.user;
		fss=fp.fss;
		sb = fss.getSuperblock();
		rightmenu = new JPopupMenu();
		inittree();
		this.setLayout(null);
		jsp=new JScrollPane(tree);
		jsp.setBounds(0,70,220,430);
		this.add(jsp);

		final Font font=new Font("΢���ź�",Font.BOLD,14);		
		jl=new JLabel[12];
		jt=new JTextField[12];
		
		//��ʾ�ļ���Ϣ

		for(int i=1;i<=5;i++){
			jt[i]=new JTextField();
		}
		
		//��ʾ������Ϣ
    	jl[11]=new JLabel("=== �� �� �� �� ===");
		jl[6]=new JLabel("�ܿռ�:");
		jl[7]=new JLabel("ʣ��ռ�:");
		jl[8]=new JLabel("���С:");
		jl[9]=new JLabel("ʣ���:");
		jl[10]=new JLabel("ʣ������:");
		jl[11].setBounds(290,285,200,23);
		//this.add(jl[11]);
		for(int i=6;i<=10;i++){
			jl[i].setBounds(240,290+23*(i-5),80,23);
			//this.add(jl[i]);
		}          
		for(int i=6;i<=10;i++){
			jt[i]=new JTextField();
			jt[i].setBounds(320, 290+23*(i-5), 120, 23);
			jt[i].setEditable(false);
			//this.add(jt[i]);
		}     
		jt[6].setText("51200B");
		jt[8].setText("512B");       
		 
		 
		//��ʾ·��
		jt[0]=new JTextField(nowpath);
		jt[0].setEditable(false);
		jt[0].setBounds(0,40,220,30);
		jt[0].setFont(font);
		this.add(jt[0]);
		
		//�����û���������
		JButton jb=new JButton("�û�����");
		jb.setEnabled(user.getIsAdmin());
		jb.addActionListener(this);
		jb.setBounds(0,5,100,30);
		this.add(jb);
		JButton jb2=new JButton("�鿴�û�");
		jb2.addActionListener(this);
		jb2.setBounds(100,5,100,30);
		this.add(jb2);
		JButton jb3=new JButton("�鿴����");
		jb3.addActionListener(this);
		jb3.setBounds(200,5,100,30);
		this.add(jb3);
		
		//����λͼ���
		bp=new BitPanel(fp);
		bp.setBounds(220,40,250,450);
		this.add(bp);
		
	}
	//�����ļ�����ص���������
	public boolean isokStr(String s){
		if(s.equals("")||s.length()>13)return false;
		for(int i=0;i<s.length();i++){
			char c=s.charAt(i);
			if(c>='a'&&c<='z'||c>='A'&&c<='Z'||c>='0'&&c<='9'||c=='.')continue;
			return false;
		}
		return true;
	}
	public String inputName(){
		String rs=JOptionPane.showInputDialog("��������(ֻ������ĸ�����������)");
		if(rs==null)return null;
		if(!isokStr(rs)){
			JOptionPane.showMessageDialog(this, "�ļ����Ƿ�!");
			return null; 
		}
		return rs;
	}
	
	//���ļ������г�ʼ��
	String nowuserpath="",userpath="";
	public void inittree(){
		//�����Ҽ��˵�
		Icon button1 = new ImageIcon("./src/icons/newFile.jpg");
		Icon button2 = new ImageIcon("./src/icons/deleteFile.png");
		Icon button3 = new ImageIcon("./src/icons/newDir.jpg");
		Icon button4 = new ImageIcon("./src/icons/deleteDir.gif");
		Icon button5 = new ImageIcon("./src/icons/rw.jpg");
		Icon button6 = new ImageIcon("./src/icons/property.png");
		
		icon=new ImageIcon[6];
//		icon[0]=new ImageIcon("./src/icons/menu_add.gif");
//		icon[1]=new ImageIcon("./scr/icons/menu_del.gif");
//		icon[2]=new ImageIcon("./scr/icons/newDir.jpg");
//		icon[3]=new ImageIcon("./scr/icons/deleteDir.gif");
//		icon[4]=new ImageIcon("./scr/icons/rw.jpg");
//		icon[5]=new ImageIcon("./scr/icons/property.png");
		
		jm = new JMenuItem[6];		
		jm[0] = new JMenuItem("�½��ļ�",button1);
		jm[1] = new JMenuItem("ɾ���ļ�",button2);
		jm[2] = new JMenuItem("�½�Ŀ¼",button3);
		jm[3] = new JMenuItem("ɾ��Ŀ¼",button4);
		jm[4] = new JMenuItem("��д�ļ�",button5);
		jm[5] = new JMenuItem("�ļ�����",button6);
		
		
		//���ӵ��Ҽ��˵�����
		rightmenu.add(jm[0]);
		rightmenu.add(jm[1]);
		rightmenu.add(jm[2]);
		rightmenu.add(jm[3]);
		rightmenu.add(jm[4]);
		rightmenu.add(jm[5]);
		
		nodes=new DefaultMutableTreeNode[80];
		//bfs��ʼ����
		NodeData rt=new NodeData(1,0,"#");
		nodes[0]=new DefaultMutableTreeNode(rt);
		LinkedList<NodeData> q=new LinkedList<NodeData>();
		q.add(rt);
		while(q.size()>0){
			NodeData nd=q.getFirst();
			q.removeFirst();
			NodeData []nnd=fss.getchild(nd.inode);
			for(int i=0;i<nnd.length;i++){
				nodes[nnd[i].inode]=new DefaultMutableTreeNode(nnd[i]);
				nodes[nd.inode].add(nodes[nnd[i].inode]);
				if(nnd[i].type==1)q.add(nnd[i]);
			}
		}		
		//�ø��ڵ��½�����������Ⱦ�������õ���ѡ��ģʽ
		tree=new JTree(nodes[0]);
		tree.setEditable(true);
		tree.setRootVisible(false);
		tree.setCellRenderer(new MyRenderer());
		tree.setRowHeight(20);
		
		model=(DefaultTreeModel)tree.getModel();
		//�Զ�չ��
		for(int i=0;i <tree.getRowCount();i++)tree.expandRow(i);
		
		tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
		//����ѡ�иı�ʱ�ļ���
		
		
		tree.add(rightmenu);
		tree.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				show(tree,e.getX(),e.getY());
			}
			
		});
		
		tree.addTreeSelectionListener(new TreeSelectionListener() {
			@Override
			public void valueChanged(TreeSelectionEvent e) {
				//������ʾ������
				if(e.getNewLeadSelectionPath()==null)return;
				String str=e.getNewLeadSelectionPath().toString();
				nowpath="";
				nowuserpath="";//ѡ���û�Ŀ¼
				userpath="#/home/"+user.getUserName();//��ǰ�û�Ŀ¼
				//���ȡ���ڶ���
				int dd=0;
				for(int i=0;i<str.length();i++){
					char s=str.charAt(i);
					if(s=='['||s==']'||s==' ')continue;
					if(s==','){
						dd++;
						if(dd==3)nowuserpath=nowpath;
						nowpath+='/';
					}
					else nowpath+=s;
				}
				if(dd<3)nowuserpath=nowpath;
				jt[0].setText(nowpath);
				//ȡ����ǰѡ���NodeData����
				DefaultMutableTreeNode dtn=(DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
				NodeData nd=(NodeData)dtn.getUserObject();
				//����ѡ�еĶ�����ʾ��Ӧ����Ϣ
				int type=nd.type;
				if(type==1){
					sb.bitblock[11+nd.inode] = 2;
					sb.bitindex[nd.inode] = 2;
					mf=fss.readdir(nowpath);
					jm[0].setEnabled(true);//�����ļ�
					jm[1].setEnabled(false);//ɾ���ļ�
					jm[2].setEnabled(true);//�½�Ŀ¼
					jm[3].setEnabled(true);//ɾ��Ŀ¼
					jm[4].setEnabled(false);
				}else{
					sb.bitblock[11+nd.inode] = 2;
					sb.bitindex[nd.inode] = 2;
					mf=fss.readfile(nowpath);
					jm[0].setEnabled(false);
					jm[1].setEnabled(true);
					jm[2].setEnabled(false);
					jm[3].setEnabled(false);
					jm[4].setEnabled(true);
				}
				bp.repaint();
				if(!nowuserpath.equals(userpath)&&!user.getIsAdmin()){
					for(int i=0;i<4;i++){
						jm[i].setEnabled(false);
					}
				}								
				TreeNode tn=dtn.getParent();
				//�ǿ�Ŀ¼�Լ���Ŀ¼���ܱ�ɾ��
				if(dtn.getChildCount()!=0)jm[3].setEnabled(false);
				if(tn.toString().equals("#"))jm[3].setEnabled(false);
				jt[1].setText(mf.fname);
				jt[2].setText(type==1?"Ŀ¼":"�ļ�");
				jt[3].setText(mf.fsize+"B");
				jt[4].setText(new Integer(mf.fownid).toString());
				String s=mf.ftime,s2="";
				s2=s.substring(0,4)+"/"+s.substring(4,6)+"/"+s.substring(6,8)+" ";
				s2+=s.substring(8,10)+":"+s.substring(10);
				jt[5].setText(s2);	
			}
		});
		//�Ҽ��¼�����
		jm[0].addActionListener(new ActionListener() {//�½��ļ�		
			public void actionPerformed(ActionEvent e) {
				String ss=inputName();
				if(ss==null)return;
				int ii=fss.mkfile(nowpath, ss, "",user);
				if(ii==0)return;
				DefaultMutableTreeNode dtn=(DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
				NodeData nd=(NodeData)dtn.getUserObject();
				
				NodeData tmp[]=fss.getchild(nd.inode);
				NodeData nnd=tmp[tmp.length-1];
				nodes[nnd.inode]=new DefaultMutableTreeNode(nnd);
				dtn.add(nodes[nnd.inode]);
				tree.expandPath(tree.getSelectionPath());
			}
		});
		jm[1].addActionListener(new ActionListener() {//ɾ���ļ�
			public void actionPerformed(ActionEvent e) {
				fss.rmfile(nowpath);
				jm[4].setEnabled(false);
				DefaultMutableTreeNode dtn=(DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
				model.removeNodeFromParent(dtn);
			}
		});
		jm[2].addActionListener(new ActionListener() {//�½�Ŀ¼
			public void actionPerformed(ActionEvent e) {
				String ss=inputName();
				if(ss==null)return;
				int ii=fss.mkdir(nowpath, ss,user);
				if(ii==0)return;
				DefaultMutableTreeNode dtn=(DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
				NodeData nd=(NodeData)dtn.getUserObject();
				NodeData tmp[]=fss.getchild(nd.inode);
				NodeData nnd=tmp[tmp.length-1];
				nodes[nnd.inode]=new DefaultMutableTreeNode(nnd);
				dtn.add(nodes[nnd.inode]);
				tree.expandPath(tree.getSelectionPath());	
			}
		});
		jm[3].addActionListener(new ActionListener() {//ɾ��Ŀ¼
			public void actionPerformed(ActionEvent e) {
				fss.rmdir(nowpath);
				DefaultMutableTreeNode dtn=(DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
				((DefaultTreeModel)tree.getModel()).removeNodeFromParent(dtn);
			}
		});
		jm[4].addActionListener(new ActionListener() {//��д�ļ�
			public void actionPerformed(ActionEvent e) {
				fd=new FileeditDialog(parent, mf.fname, mf.fcont,userpath.equals(nowuserpath)||user.getIsAdmin());
				if(fd.change==false)return;
				int iid=fss.writefile(nowpath, fd.name, fd.cont);
				DefaultMutableTreeNode dtn=(DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
				NodeData nd=(NodeData)dtn.getUserObject();
				dtn.setUserObject(new NodeData(nd.type,nd.inode,fd.name));
				//fss.mkBlock1(nowpath);
				tree.repaint();
			}
		});
		
		jm[5].addActionListener(new ActionListener() {//�ļ�����
			public void actionPerformed(ActionEvent e) {
				fpp.setTextField(jt);
				fpp.setVisible(true);
				//fss.mkBlock2(nowpath);			    
				//System.out.println(nowpath);
			}
		});
	}
	public void show(JTree tree,int x,int y) {
		rightmenu.show(tree,x,y);
	}
	
	//��������
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("�û�����")){
			//�û���������
			UserViewManager manager = new UserViewManager(user); 			
		}else if(e.getActionCommand().equals("�鿴�û�")){			
			UserView userView = new UserView(user);
		    for(UserThread userT:InitThread.threadList){
				System.out.println(userT);
			}		
		}else if(e.getActionCommand().equals("�鿴����")){
			dp.setTextField(jt);
			dp.setVisible(true);
		
		}
		
		tree.updateUI();
		bp.repaint();
	}
}

//������Ⱦ��,��Ҫ����������ͼ��
class MyRenderer extends DefaultTreeCellRenderer{
	@Override
	public Component getTreeCellRendererComponent(JTree tree, Object value,
			boolean sel, boolean expanded, boolean leaf, int row,
			boolean hasFocus) {
		super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
		//���ݽڵ�����ѡ��ͬ��ͼ��
		DefaultMutableTreeNode node=(DefaultMutableTreeNode)value;
		NodeData data=(NodeData)node.getUserObject();
		ImageIcon icon=null;
		if(data.type==1){
			icon=new ImageIcon("1.jpg");
		}else if(data.type==2){
			icon=new ImageIcon("2.jpg");
		}
		this.setFont(new Font("΢���ź�",0,15));
		this.setIcon(icon);
		return this;
	}
}
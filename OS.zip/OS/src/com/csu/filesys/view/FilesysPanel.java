package com.csu.filesys.view;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.UIManager;

import cn.csu.user.domain.User;

import com.csu.filesys.server.FilesysServer;

public class FilesysPanel extends JFrame{
	private static final long serialVersionUID = 1L;

	FileTreePanel ft;
	public FilesysServer fss;
	public User user;
	public FilesysPanel(FilesysServer fss,User user){
		
		this.fss=fss;
		this.user=user;
		this.setLayout(null);
		ft=new FileTreePanel(this);
		this.add(ft);	
		ft.setBounds(0,0,700,540);
		int sw=(int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int sh=(int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setSize(500,540);
		this.setLocation(sw/2-460, sh/2-300);
		this.setResizable(false);
		this.setTitle("�ļ������--[�û���:"+user.getUserName()+"][����Ա:"+user.getIsAdmin()+"]");
		this.setVisible(true);
		//this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
}

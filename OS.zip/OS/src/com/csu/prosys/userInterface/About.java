package com.csu.prosys.userInterface;
/**
 * @author syt
 * ���ý���ı߽������*/
import javax.swing.JFrame;

public class About extends JFrame{
	public About(MainFrame frame){
		this.setBounds(frame.getX()+frame.getWidth()/2-150, frame.getY()+frame.getHeight()/2-100, 300, 200);
		this.setVisible(true);
	}
}

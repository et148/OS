package com.csu.prosys.userInterface;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

import com.csu.prosys.util.BlockQueue;
import com.csu.prosys.util.PartitionTable;
import com.csu.prosys.util.ReadyQueue;
import com.csu.prosys.vo.PCB;
import com.csu.prosys.vo.Queue;


public class MemoryPanel extends JPanel{
	public final static int width = 80;
	public final static int height =480;
	
	
	public MemoryPanel(){
		this.setBounds(15,50, MemoryPanel.width, MemoryPanel.height);
	}
	
	public void paint(Graphics g){
		System.out.println("##############");
		g.clearRect(0, 0, MemoryPanel.width, MemoryPanel.height);
		g.setColor(Color.black);
		g.drawRect(0, 0, MemoryPanel.width-1, MemoryPanel.height-1);
		Queue ready = ReadyQueue.getQueue();
		Queue block = BlockQueue.getQueue();
		PCB temp = ready.getFirst();
		double maxSize = PartitionTable.memory_maxSize;
		while(temp!=null){
			if(temp.getColor()==null){//���û����ɫ��Ҳ����˵�Ǹո��½����ģ���ô�͸�һ���������ɫ
				temp.setColor(this.createRandomColor());
			}
			System.out.println(temp.getPID()+","+temp.getStartLocation());
			g.setColor(temp.getColor());
			double start = temp.getStartLocation();//???��ô��ʼ�ͻ���λ�ã�
			
			double need = temp.getMemoryNeed();
			int x = (int)(start/maxSize*MemoryPanel.height);
			int w = (int)((need/maxSize)*MemoryPanel.height);
			g.fillRect(1,
					x+1,
					MemoryPanel.width-2,
					w);
			temp = temp.getNext();
		}
		temp = block.getFirst();
		while(temp!=null){
			if(temp.getColor()==null){
				temp.setColor(this.createRandomColor());
			}
			g.setColor(temp.getColor());
			double start = temp.getStartLocation();
			double need = temp.getMemoryNeed();
			int x = (int)(start/maxSize*MemoryPanel.height);
			int w = (int)((need/maxSize)*MemoryPanel.height);
			g.fillRect(1,
					(temp.getStartLocation()/PartitionTable.memory_maxSize)*MemoryPanel.height+1,
					MemoryPanel.width-2,
					(temp.getMemoryNeed()/PartitionTable.memory_maxSize)*MemoryPanel.height);
			temp = temp.getNext();
		}
		
		
	}
	
	public Color createRandomColor(){
		return new Color((new Double(Math.random() * 128)).intValue() + 128,
				(new Double(Math.random() * 128)).intValue() + 128,
				(new Double(Math.random() * 128)).intValue() + 128);
	}
	
 }

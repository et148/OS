package com.csu.prosys.userInterface;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.csu.prosys.scheduling.Scheduling;
import com.csu.prosys.util.ReadyQueue;
import com.csu.prosys.util.ReserveQueue;
import com.csu.prosys.vo.PCB;
import com.csu.thread.manager.TaskList;
/**
 * @author syt
 * ������ұ��Ǹ������ʵ��*/

public class RunningPanel extends JPanel implements ActionListener,ChangeListener{
	public final static int width = 1000;
	public final static int height = 1000;
	JPanel pr=new JPanel(new BorderLayout());
	private Scheduling scheduling;
	private ImageIcon icon;
	private JLabel imagePCB;
	private JLabel tips_systemTime;//ϵͳʱ�䣺00��00��00
	private JLabel tips_1;//���������С�������
	private JLabel tips_2;//�����������С���
	private static JProgressBar bar;//���bar�ǽ�����
	private JLabel tips_3;//�ڴ�������
	private Timer timer;//��ʱ��
	JButton btr=new JButton("�鿴ϵͳ����");
//	JLabel lbr=new JLabel();
	/**/
	private static JLabel tips_PID;
	private static JLabel tips_priority;
	private static JLabel tips_timeNeed;
	private static JLabel tips_memoryNeed;
    static MemoryPanel memoryPanel;//���ڴ�ķ�����Ǹ����
    static JLabel jbm=new JLabel("�ڴ����",JLabel.HORIZONTAL);
	private int hour;
	private int minute;
	private int second;
	private int count = 0;
	
	
	public RunningPanel(Scheduling scheduling){
		this.scheduling = scheduling;
		this.setBounds(0, 0,RunningPanel.width, RunningPanel.height);
		this.setLayout(null);
		this.setPanel();
		timer = new Timer(20,this);
		timer.start();
	}

	/*����ϵͳʱ��*/
	public String calculateSystemTime(){
		String[] zero = new String[]{"00","0",""};
		String time = zero[String.valueOf(hour).length()] + hour + ":" +zero[String.valueOf(minute).length()] + minute + ":" +zero[String.valueOf(second).length()] + second;
		return time;
	}
	
	/*�޸�ϵͳʱ��*/
	public void modifySystemTime(){
		if(second<59){
			second++;
		}else{
			second = 0;
			if(minute<59){
				minute++;
			}else{
				minute = 0;
				if(hour<59){
					hour++;
				}else{
					hour = 0;
				}
			}
		}
	}
	
	/*��������ϵ�һЩ�ؼ�*/
	public void setPanel(){
		this.setLayout(new BorderLayout());
		tips_systemTime = new JLabel("��ǰϵͳʱ�䣺00:00:00");
		tips_systemTime.setHorizontalAlignment(SwingConstants.CENTER);
		tips_systemTime.setBounds(20, 0, 300, 20);//���ñ�ǩ�Ĵ�С
		tips_systemTime.setFont(new Font("����",Font.BOLD,16));
		tips_systemTime.setForeground(new Color(73,69,121));//������ɫ ����Ҫ�ı���ɫ
		this.add(tips_systemTime,BorderLayout.NORTH);
		tips_1 = new JLabel("�������еĽ���:");
		tips_1.setBounds(20, 20, 100, 30);
//		this.add(tips_1,BorderLayout.WEST);
		
		tips_PID = new JLabel("PID:");
		tips_PID.setBounds(180, 10, 200, 30);
		pr.add(tips_PID,BorderLayout.CENTER);
		tips_priority = new JLabel("PRIORITY:");
		tips_priority.setBounds(180, 30, 200, 30);
		pr.add(tips_priority);
		tips_timeNeed = new JLabel("TIMENEED:");
		tips_timeNeed.setBounds(180, 50, 200, 30);
		pr.add(tips_timeNeed);
		tips_memoryNeed = new JLabel("MEMORYNEED:");
		tips_memoryNeed.setBounds(180, 70, 200, 30);		
		pr.add(tips_memoryNeed);		
		pr.setBackground(new Color(253,255,233));
		this.add(pr,BorderLayout.CENTER);
		icon = new ImageIcon(MainFrame.class.getResource("/icons/p.JPG"));
		imagePCB = new JLabel(icon);
		imagePCB.setBounds(50, 10, icon.getIconWidth(), icon.getIconHeight());
		pr.add(imagePCB);
		pr.add(btr);
		btr.setBounds(0, 115, 420, 20);
		btr.setForeground(new Color(73,69,121));
		btr.setFont(new Font("����",Font.BOLD,16));
		btr.addActionListener(this);

		tips_3 = new JLabel("");
		tips_3.setBounds(20, 200, 100, 30);pr.add(tips_3);
		bar = new JProgressBar();
		bar.setMinimum(0);
		bar.setMaximum(100);
		bar.setOrientation(JProgressBar.HORIZONTAL);
		bar.setBorderPainted(true);
		bar.setForeground(new Color(247,196,130));
		bar.setStringPainted(true);
		bar.setPreferredSize(new Dimension(200,20));
		bar.setBounds(20, 135,300, 25);/**##�����ڴ���λ�ô�С*/
		bar.addChangeListener(this);
		this.add(bar,BorderLayout.SOUTH);
		this.setBackground(new Color(239,236,193));
		memoryPanel = new MemoryPanel();
		jbm.setBounds(5,50,490,25);
	}

/*****************************************2018.5.30*********************************************/
	public void actionPerformed(ActionEvent e) {
		count++;
		if(count==50){
			this.modifySystemTime();
			this.tips_systemTime.setText("��ǰϵͳʱ�䣺" + this.calculateSystemTime());
			count = 0;
		}
		
		if(e.getSource()==btr) {
			new TaskList();
		}
	}
	
	public void stateChanged(ChangeEvent e) {
	}

	public int getHour() {
		return hour;
	}

	public void setHour(int hour) {
		this.hour = hour;
	}

	public int getMinute() {
		return minute;
	}

	public void setMinute(int minute) {
		this.minute = minute;
	}

	public int getSecond() {
		return second;
	}

	public void setSecond(int second) {
		this.second = second;
	}

	public static JProgressBar getBar() {
		return bar;
	}

	public static void setBar(JProgressBar bar) {
		RunningPanel.bar = bar;
	}

	public static JLabel getTips_PID() {
		return tips_PID;
	}

	public static void setTips_PID(JLabel tips_PID) {
		RunningPanel.tips_PID = tips_PID;
	}

	public static JLabel getTips_priority() {
		return tips_priority;
	}

	public static void setTips_priority(JLabel tips_priority) {
		RunningPanel.tips_priority = tips_priority;
	}

	public static JLabel getTips_timeNeed() {
		return tips_timeNeed;
	}

	public static void setTips_timeNeed(JLabel tips_timeNeed) {
		RunningPanel.tips_timeNeed = tips_timeNeed;
	}

	public static JLabel getTips_memoryNeed() {
		return tips_memoryNeed;
	}

	public static void setTips_memoryNeed(JLabel tips_memoryNeed) {
		RunningPanel.tips_memoryNeed = tips_memoryNeed;
	}

	public static MemoryPanel getMemoryPanel() {
		return memoryPanel;
	}

	public static void setMemoryPanel(MemoryPanel memoryPanel) {
		RunningPanel.memoryPanel = memoryPanel;
	}

	
	
}

package com.csu.prosys.util;

import com.csu.prosys.vo.Queue;

public class ResumeQueue {
	private static Queue queue;
	
	
	public ResumeQueue(){
		queue = new Queue();
	}

	public static Queue getQueue() {
		return queue;
	}


	public static void setQueue(Queue queue) {
		ResumeQueue.queue = queue;
	}
		
	
}

package com.csu.system.main;
import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;

import javax.swing.UIManager;

import com.csu.filesys.server.FilesysServer;

import cn.csu.user.view.LoginView;
//���������
public class MainImport {
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		} catch (Exception e) {
			e.printStackTrace();
		}
		try
        {
    		BeautyEyeLNFHelper.frameBorderStyle = BeautyEyeLNFHelper.FrameBorderStyle.osLookAndFeelDecorated;
            org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
        }
        catch(Exception e)
        {
            //TODO exception
        }
		FilesysServer fss;
		fss=new FilesysServer("disk1.txt");
		//��ʼ��
		LoginView lw = new LoginView(fss);
	}
}
